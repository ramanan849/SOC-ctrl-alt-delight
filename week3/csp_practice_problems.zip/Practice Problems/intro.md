# Practice Problems

These problems are for your practice. We won't provide solutions for these problems, although you can ask doubts